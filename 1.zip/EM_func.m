function EM_func(centroids)

list = vertcat(centroids{:});
centroids_number = length(list);
numClusters = 3;

% Initialize parameters with random values

mu_x = repmat(rand(centroids_number, 1), [1, numClusters]);  % mean vector x
sigma_x = repmat(eye(centroids_number), [1, 1, numClusters]); % covariance matrix
pi_x = repmat(rand(centroids_number, 1), [1, numClusters]);  % mixing coefficient

mu_y = repmat(rand(centroids_number, 1), [1, numClusters]);  % mean vector y
sigma_y = repmat(eye(centroids_number), [1, 1, numClusters]); % covariance matrix
pi_y = repmat(rand(centroids_number, 1), [1, numClusters]);  % mixing coefficient


% Initialize log-likelihood and iteration counter
loglik = -inf;
maxIters = 100;
iter = 0;

while iter < maxIters

    p_x = zeros(centroids_number, numClusters);  
    p_y = zeros(centroids_number, numClusters); 

    for i=1:numClusters
        p_x(:, i) = mvnpdf(list(:, 1), mu_x(:, i), sigma_x(:, :, i))*pi_x(:, i);
        p_y(:, i) = mvnpdf(list(:, 2), mu_y(:, i), sigma_y(:, :, i))*pi_y(:, i);
    end
    
