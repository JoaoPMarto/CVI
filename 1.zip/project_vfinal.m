%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% Ground Truth %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
% Load the image sequence and ground truth data
%data = dlmread('gt.txt'); %forma antiga de ir buscar os dados
data = readmatrix("gt.txt");
path = 'View_001/frame_'; 
frameIdComp = 4;
str = ['%s%.' num2str(frameIdComp) 'd.%s'];
nFrame = 50; % 794
figure; hold on



%%% Performance
list_gt_x_min = cell(nFrame,1);
list_gt_x_max = cell(nFrame,1);
list_gt_y_min = cell(nFrame,1);
list_gt_y_max = cell(nFrame,1);

for k = 1 : nFrame
   % Load the current frame
    fprintf('Iteration %d\n', k);
    str1 = sprintf(str,path,k,'jpg');
    img = imread(str1);
    imshow(img); % showing image
    hold on;
  
    % Get indices of bounding boxes for the current frame
    frameRows = find(data(:,1) == k);
    
    
    %%% Performance
    gt_x_min = zeros(length(frameRows),1);
    gt_x_max = zeros(length(frameRows),1);
    gt_y_min = zeros(length(frameRows),1);
    gt_y_max = zeros(length(frameRows),1);

    % Perform tracking for each detection in the current frame
    for i = 1:length(frameRows)
        row = frameRows(i);
        if data(row,8) ~= -1 % if 3D x position is available
            x = data(row,3); % Bounding box left
            y = data(row,4); % Bounding box top
            w = data(row,5); % Bounding box width
            h = data(row,6); % Bounding box height
            id = data(row,2); % identity number
            
            %%% Performance
            gt_x_min(i) = x;
            gt_x_max(i) = x+w;
            gt_y_min(i) = y+h;
            gt_y_max(i) = y;

            

            % Draw the bounding box with color red
            color = [1 0 0]; % red
            rectangle('Position', [x, y, w, h], 'EdgeColor',	color, 'LineWidth', 2);

            % Add a text label to the bounding box indicating the identity number
            text(x, y-10, sprintf('ID %d', id), 'Color', color, 'FontSize', 12, 'FontWeight', 'bold');
        end
        %%% Performance
        list_gt_x_min{k} = gt_x_min;
        list_gt_x_max{k} = gt_x_max;
        list_gt_y_min{k} = gt_y_min;
        list_gt_y_max{k} = gt_y_max;
    end
  
    % Wait for the user to press "Enter" before showing the next frame
    %pause; % if you want for this image to run more smoothly, then thisline
    drawnow;



end
fprintf('Ground Truth over.')
%% first way to obtain background: low-pass filter

nFramesForThis = 30;
alpha=0.01;
background = get_background(str, path,nFramesForThis,alpha);


%% second way to obtain background: median filter
nFramesForThis = 30;
background_median = median_background(str, path,nFramesForThis);

%% applying detector algorithm 
% (and saving the centroids for later stuff)
minArea = 400;
maxArea = 100000;
minAspect = 0.2;
maxAspect = 0.8;
nFramesToKeep = 200; % amount of frames for which we keep the past path taken
background_image = background_median;
threshold_value = 30;

close all
[list_centroids, list_x_min, list_x_max, list_y_min, list_y_max] = detector_func_v1(minArea,maxArea,minAspect,maxAspect,nFrame,nFramesToKeep,background_image,threshold_value);


%% heatmap (dynamic and static)
close all
hm_x = 768;
hm_y = 576;
display_heatmap_func(hm_y, hm_x, nFrame, list_centroids, background)






%% performance measures




close all



plot_IoU = zeros(nFrame);

for k = 1:nFrame

    frame_gt_x_min = list_gt_x_min{k}; 
    frame_gt_x_max = list_gt_x_max{k};
    frame_gt_y_min = list_gt_y_min{k};
    frame_gt_y_max = list_gt_y_max{k};

    frame_x_min = list_x_min{k}; 
    frame_x_max = list_x_max{k};
    frame_y_min = list_y_min{k};
    frame_y_max = list_y_max{k};


    % iterating over each pedestrian


    %%%% create matrix_gt and matrix
    matrix_gt = get_binary_image_boxes(frame_gt_x_min,frame_gt_x_max,frame_gt_y_min,frame_gt_y_max);
    matrix_detector = get_binary_image_boxes(frame_x_min,frame_x_max,frame_y_min,frame_y_max);
    %%%%%%


    % IoU
    region_union = matrix_gt+matrix_detector;
    region_union(region_union == 2) = 1;
    union= sum(region_union(:));

    region_intersection = matrix_gt+matrix_detector;
    region_intersection(region_intersection == 1) = 0;
    region_intersection(region_intersection == 2) = 1;
    intersection = sum(region_intersection(:));


    plot_IoU(k) = intersection/union;
    %imshow(bg_overlay(get_frame(k), matrix_gt,0.99))
    
    %imshow(bg_overlay(get_frame(k), matrix_detector,0.99))
    %imshow(region_intersection)
end


%% finally plotting IoU

plot(plot_IoU)
title('Success plot, regarding IoU')


%% EM algorithm is incomplete, but we send the function along as well


%% some auxiliary functions

function blendedImage = bg_overlay(background, heatmap,alpha)
% alpha value meaning:
% if you want overlay: 0.99; if you only want heatmap: 1

% Create a new image by blending the background image and the heatmap
blendedImage = (1-alpha)*double(background) + alpha*double(heatmap);

% Normalize the blended image to the range [0, 255]
blendedImage = uint8(blendedImage / max(blendedImage(:)) * 255);

end

function frame = get_frame(i)
    path = 'View_001/frame_'; 
    frameIdComp = 4;
    str = ['%s%.' num2str(frameIdComp) 'd.%s'];
    filename = sprintf(str, path, i, 'jpg');
    frame = imread(filename);
end

function matrix_gt = get_binary_image_boxes(frame_gt_x_min,frame_gt_x_max,frame_gt_y_min,frame_gt_y_max)
matrix_gt = zeros(576,768);
for i = 1:length(frame_gt_y_max)
    
    gt_x_min = round(frame_gt_x_min(i));
    gt_x_max = round(frame_gt_x_max(i));
    gt_y_min = round(frame_gt_y_min(i));
    gt_y_max = round(frame_gt_y_max(i));
    
    
    if gt_x_max==0
        gt_x_max=1;
    end
    if gt_x_max==769
        gt_x_max=768;
    end
    if gt_y_max==0
        gt_y_max=1;
    end
    if gt_y_max==577
        gt_y_max=576;
    end
    if gt_x_min==0
        gt_x_min=1;
    end
    if gt_x_min==769
        gt_x_min=768;
    end
    if gt_y_min==0
        gt_y_min=1;
    end
    if gt_y_min==577
        gt_y_min=576;
    end
    
    
    
    gt_y_range = gt_y_max:gt_y_min;
    gt_x_range = gt_x_min:gt_x_max;
    
    matrix_gt(gt_y_range,gt_x_range) = 1;
    %imshow(matrix_gt)
    
    
    
    
end
end